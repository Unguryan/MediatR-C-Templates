﻿namespace $rootnamespace$
{
   public record $safeitemrootname$();
}
