using MediatR;

namespace $rootnamespace$
{
    public record $safeitemrootname$() : IRequest<$safeitemrootname$Result>;
}
